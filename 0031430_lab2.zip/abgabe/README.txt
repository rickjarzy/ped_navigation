um den sourcecode auf seine lauff�higkeit zu �berpr�fen wird folgendes ben�tigt:
python 3.7 ( damit habe ich entwickelt).
eine umgebungsvariable (PATH bei windows, linux is mir momentan enfallen) muss zum python.exe hinzeigen um das programm �ber die cmd starten zu k�nnen
das programm verwendet libs wie numpy, matplotlib und pandas, diese k�nnen wenn die oben genannten schritte umgesetzt sind
einfachst mit folgendem cmd command installiert werden 

pip install -r requirements.txt .... die cmd muss in das verzeichnis des requirements.txt wechseln oder der ganze pfad als argument �bergeben

der trajektoriernplot ist mit einem matlabskript erstellt worden, hierzu m�ssen die 6 txt files im gleichen verzeichnis sein wie das skript selbst

dann sollte die sache funktionerien
bei fragen oder problemen bitte mich zu benachrichtigen, ich kann gerne weiterhelfen

Lg - hat spass gemacht
Paul Arzberger
